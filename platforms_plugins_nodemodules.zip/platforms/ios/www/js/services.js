angular.module('cnc.services', [])

/**
 * 请求、响应拦截器
 */
.factory('Interceptor', function($q) {
        var mock = false;

        function parseUrl(urlString) {
            var url = {
                url: urlString,
                host: '/',
                path: '',
                params: {}
            }
            var arrUrl = urlString.split("//");
            if (arrUrl[1]) {
                var idx = arrUrl[1].indexOf('/');
                if (idx == -1)
                    idx = arrUrl[1].length - 1;
                url.host = arrUrl[1].substring(0, idx);
                url.path = arrUrl[1].substring(idx + 1);
                idx = url.path.indexOf('?');
                if (idx != -1) {
                    var param = url.path.substring(idx + 1);
                    url.path = url.path.substring(0, idx);
                    param = param.split('&').filter(function(el) {
                        return el.length > 0
                    })
                    param.forEach(function(el) {
                        var info = el.split('=');
                        if (info[1]) {
                            url.params[info[0]] = info[1]
                        }
                    })
                }
            } else {
                url.path = urlString
            }
            return url
        }
        return {
            mock: mock,
            request: function(config) {
                var deferred = $q.defer();
                if (mock) {
                    var urlObj = parseUrl(config.url);
                    if (urlObj.host != '/' && urlObj.params.command) {
                        config.url = 'mock/' + urlObj.params.command + '.json';
                    }
                }
                deferred.resolve(config);
                return deferred.promise;
            },
            response: function(response) {
                var deferred = $q.defer();
                deferred.resolve(response);
                return deferred.promise;
            }
        }
    })
    .factory('network', function() {
        var ip = 'http://10.6.78.186:8080/cnc/'; //http://10.6.78.186:8080/cnc/
        return {
            ip: ip
        }
    })

.factory('User', function($http, network) { //用户登录与服务器会话连接
        var localStorage = window.localStorage;
        var username = localStorage.getItem('cnc_user') || ''; //admin
        var psw = localStorage.getItem('cnc_psw') || ''; //byd@123
        return {
            username: username,
            psw: psw,
            login: function(user) {
                // console.log(network.ip+'BydInterfaceService.do?command=checkLogin&withNoPwd=1&loginId=' + user.username + '&password=' + user.psw);
                var promise = $http.get(network.ip + 'BydInterfaceService.do?command=checkLogin&withNoPwd=1&loginId=' + user.username + '&password=' + user.psw);
                return promise;
            },
            saveUser: function() {
                localStorage.setItem('cnc_user', this.username);
                localStorage.setItem('cnc_psw', this.psw);
            },
            resetUser: function() {
                localStorage.removeItem('cnc_user');
                localStorage.removeItem('cnc_psw');
            }
        }
    })
    .factory('facList', function($http, network) {
        var factories = [];
        var colors = {
            "positive": "#387ef5",
            "balanced": "#33cd5f",
            "energized": "#ffc900",
            "assertive": "#ef473a"
        }
        var size = 10;
        // var ratio=1;
        return {
            factories: factories,
            fetchMainData: function() {
                console.log(network.ip + 'BydInterfaceService.do?command=getJdlAndLxxcc&withNoPwd=1');
                var promise = $http.get(network.ip + 'BydInterfaceService.do?command=getJdlAndLxxcc&withNoPwd=1');
                return promise;
            },
            fetchUtiData: function(date, fac) {
                // fac = encodeURI(fac);
                // console.log(network.ip + 'BydInterfaceService.do?command=getJdl&withNoPwd=1&param={P_DATE:'+date+',P_FACTORY:'+fac+'}')
                var promise = $http.get(network.ip + 'BydInterfaceService.do?command=getJdl&withNoPwd=1&param={P_DATE:' + date + ',P_FACTORY:' + fac + '}');
                return promise;
            },
            fetchOutputsData: function(date, fac, type) {
                // fac = encodeURI(fac);
                if (type == '') {
                    // console.log(network.ip + 'BydInterfaceService.do?command=getLxscc&withNoPwd=1&param={P_DATE:'+date+',P_FACTORY:'+fac+'}')
                    var promise = $http.get(network.ip + 'BydInterfaceService.do?command=getLxscc&withNoPwd=1&param={P_DATE:' + date + ',P_FACTORY:' + fac + '}');
                } else {
                    // console.log(network.ip + 'BydInterfaceService.do?command=getLxscc&withNoPwd=1&param={P_DATE:'+date+',P_FACTORY:'+fac+',P_PROCESS_TYPE:'+type+'}')
                    var promise = $http.get(network.ip + 'BydInterfaceService.do?command=getLxscc&withNoPwd=1&param={P_DATE:' + date + ',P_FACTORY:' + fac + ',P_PROCESS_TYPE:' + type + '}');
                }
                return promise;
            },
            fetchMachineStat: function(fac) {
                // console.log(network.ip + 'BydInterfaceService.do?command=getMachineStatus&withNoPwd=1&param={P_FACTORY:'+fac+'}');
                var promise = $http.get(network.ip + 'BydInterfaceService.do?command=getMachineStatus&withNoPwd=1&param={P_FACTORY:' + fac + '}');
                return promise;
            },
            fetchMachineStatList: function() {
                // console.log(network.ip + 'BydInterfaceService.do?command=getMachineStatusSummary&withNoPwd=1')
                var promise = $http.get(network.ip + 'BydInterfaceService.do?command=getMachineStatusSummary&withNoPwd=1');
                return promise;
            },
            // drawCanvas0:function(macList,xMax,yMax){
            //     var divBox = document.getElementById("macMap");
            //     if(document.getElementById("myCanvas")){
            //         this.clearCanvas();
            //     }
            //     var myCanvas = document.createElement("canvas");
            //     myCanvas.setAttribute("width", xMax);
            //     myCanvas.setAttribute("height", yMax);
            //     myCanvas.setAttribute("id", "myCanvas");
            //     divBox.appendChild(myCanvas);
            //     var ctx=myCanvas.getContext("2d");
            //     ratio = canvas.width/(macList[macList.length-1].x+size);
            //     canvas.height = ratio*(macList[macList.length-1].y+size);
            //     ctx.scale(ratio,ratio);
            //     for(var i=0;i<macList.length;i++){
            //         ctx.fillStyle=colors[macList[i].class_name];
            //         ctx.fillRect(macList[i].x,macList[i].y,size,size);
            //     }
            //     myCanvas.style.zoom=divBox.offsetWidth/xMax;
            // },
            // clearCanvas0:function(){
            //     var divBox = document.getElementById("macMap");
            //     var myCanvas = document.getElementById("myCanvas");
            //     divBox.removeChild(myCanvas);
            //     var canvas=document.getElementById("macMap");
            //     var ctx=canvas.getContext("2d");
            //     ctx.scale(1/ratio,1/ratio);
            //     ctx.clearRect(0,0,canvas.width,canvas.height);
            // },
            drawCanvas: function(macList, xMax, yMax) {
                var canvas = document.getElementById("myCanvas");
                var ctx = canvas.getContext("2d");
                canvas.width = xMax + size;
                canvas.height = yMax + size;
                for (var i = 0; i < macList.length; i++) {
                    ctx.fillStyle = colors[macList[i].class_name];
                    ctx.fillRect(macList[i].x, macList[i].y, size, size);
                }
                canvas.style.zoom = document.getElementById("macMap").offsetWidth / canvas.width;

            },
            clearCanvas: function() {
                var canvas = document.getElementById("myCanvas");
                var ctx = canvas.getContext("2d");
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
        }
    })

.factory('appUpdate', function($ionicPopup, $rootScope, $ionicLoading, $http, $q) {
    var APPID = "5b165289ca87a8535507fff4"; // ios app id
    var APITOKEN = "0df4b94d3492c6d71836f91b49c918a1";
    var DOWNLOADURL = "itms-services://?action=download-manifest&url=https%3A%2F%2Fdownload.fir.im%2Fapps%2F%3Aid%2Finstall%3Fdownload_token%3D";
    var version, appInfo;
    var upDatePopup;
    $rootScope.closePopup = function() {
            upDatePopup.close();
        }
        //获取最新版本信息
    function getAPPInfo() {
        if (ionic.Platform.platform() != "ios")
            return false;
        var promise1 = $http.get("http://api.fir.im/apps/latest/" + APPID + "?api_token=" + APITOKEN);
        var promise2 = $http.get("http://api.fir.im/apps/" + APPID + "/download_token?api_token=" + APITOKEN);
        $q.all([promise1, promise2])
            .then(function(result) {
                appInfo = result[0].data;
                appInfo.download_token = result[1].data.download_token;
                if (version < appInfo.version) {
                    showUpdateConfirm();
                }
                console.log(appInfo)
            }, function(error) {
                console.log(error)
            })
    }
})

.factory('appUpdate', function ($ionicPopup, $rootScope, $ionicLoading, $http, $q) {
  var APPID = "5b165289ca87a8535507fff4"; // ios app id
  var APITOKEN = "0df4b94d3492c6d71836f91b49c918a1";
  var DOWNLOADURL = "itms-services://?action=download-manifest&url=https%3A%2F%2Fdownload.fir.im%2Fapps%2F%3Aid%2Finstall%3Fdownload_token%3D";
  var version,appInfo;
  // var upDatePopup;
  // $rootScope.closePopup = function () {
  //   upDatePopup.close();
  // }
    //获取最新版本信息
    function getAPPInfo(){
      if (ionic.Platform.platform() != "ios")
      return false;
      var promise1 = $http.get("http://api.fir.im/apps/latest/" + APPID + "?api_token=" + APITOKEN);
      var promise2 = $http.get("http://api.fir.im/apps/" + APPID + "/download_token?api_token=" + APITOKEN);
        $q.all([promise1,promise2])
          .then(function(result) {
            appInfo = result[0].data;
            appInfo.download_token = result[1].data.download_token;
            if (version < appInfo.versionShort) {
              showUpdateConfirm();
            }
            // console.log(appInfo)
          },function(error){
            console.log(error)
          })
      }
    // 显示是否更新对话框
    // 浏览器打开下载，不兼容小米和三星自动安装
    function showUpdateConfirm() {
        //IOS不支持<a>标签href设置itms-services://直接安装
        console.log(DOWNLOADURL + appInfo.download_token)
        // 只能访问update_url通过safari安装
        console.log(appUpdateInfo.update_url)
        // 升级框写法一： 
        // var upDatePopup;
        // $rootScope.closePopup = function () {
        //   upDatePopup.close();
        // }
        // var contents = '<p>内容：' + appInfo.changelog + '</p>';
        // contents += '<p>大小：' + (appInfo.binary.fsize / 1024 / 1024).toFixed(2) + 'MB</p>';
        // contents += '<p>更新时间：' + (new Date(appInfo.updated_at * 1000)).toJSON().substring(0, 10) + '</p>';
        // upDatePopup = $ionicPopup.show({
        //     title: '发现新版本v' + appInfo.versionShort,
        //     template: contents + '<div class="popup-buttons"><button class="button button-default" ng-click="closePopup()">取消</button><a class="button button-positive" style="line-height:45px" ng-click="closePopup()" target="_blank" href="' + DOWNLOADURL + appInfo.download_token + '">升级</a></div>',
        //     scope: $rootScope
        // });
        // 升级框写法二：推荐
        // 默认<a>链接无法点击，需要添加以下css
          /* .popup-buttons a {
              display: block;
              text-decoration: none;
              color: white;
              line-height: 45px;
              }
              .popup-buttons .button-positive::after {
              position: unset
              } */
        var confirmPopup = $ionicPopup.confirm({
          title: '版本升级',
          template: '<div style="line-height:25px;padding-left:10px">新版本：v'+appInfo.versionShort+'<br>内容：'+appInfo.changelog+'<br>大小：'+(appInfo.binary.fsize/1024/1024).toFixed(2)+'MB<br>更新时间：'+(new Date(appInfo.updated_at*1000)).toJSON().substring(0,10)+'</div>',
          cancelText: '取消',
          okText: '<a target="_blank" href="' + appUpdateInfo.update_url + '">升级</a>'
        });
        // 以下代码可不用
        // confirmPopup.then(function (res) {
        //     if (res) {
        //       // bracelet
        //         // var url = 'http://218.17.29.94:8081/bracelet/'+appInfo.url;
        //         // if(window.cordova&&cordova.InAppBrowser)
        //         // cordova.InAppBrowser.open(url,'_system', 'location=no');
        //     } else {
        //         // 取消更新
        //     }
        // });
    }
    return {
        checkUpdate: function() {
            if (!window.cordova) {
                version = '0.1.0';
                getAPPInfo();
            } else {
                cordova.getAppVersion.getVersionNumber().then(function(v) {
                    version = v;
                    getAPPInfo();
                });
            }
        }
    }
})