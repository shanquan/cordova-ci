angular.module('cnc.routes', [])

.config(function($stateProvider, $urlRouterProvider,$ionicConfigProvider,$httpProvider) {
  $httpProvider.defaults.transformRequest = function(obj){ 
     var str = [];  
     for(var p in obj){  
       str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));  
     }  
     return str.join("&");  
   }  

  $httpProvider.defaults.headers.post = {  
    'Content-Type': 'application/x-www-form-urlencoded'  
  }
  $httpProvider.interceptors.push('Interceptor');
  $stateProvider  

  .state('login', {
    url: '/login',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('main', {
    url: '/main',
    templateUrl: 'templates/main.html',
    controller: 'mainCtrl'
  })

  .state('factory', {
    url: '/factory/:fac',
    templateUrl: 'templates/factory.html',
    controller: 'factoryCtrl'
  })
  .state('machineStatList', {
    url: '/machineStatList',
    templateUrl: 'templates/machineStatList.html',
    controller: 'machineStatListCtrl'
  })
  .state('utilizationRate', {
    url: '/utilizationRate/:fac',
    templateUrl: 'templates/utilizationRate.html',
    controller: 'utilrCtrl'
  })

  .state('2hOutput', {
    url: '/2hOutput/:fac',
    templateUrl: 'templates/2hOutput.html',
    controller: '2hOutputCtrl'
  })

  .state('machineStat', {
    url: '/machineStat/:fac',
    templateUrl: 'templates/machineStat.html',
    controller: 'machineStatCtrl'
  })

$urlRouterProvider.otherwise('/login')
$ionicConfigProvider.backButton.text('返回');
$ionicConfigProvider.scrolling.jsScrolling(true); //允许缩放
})