angular.module('cnc.controllers', [])

.controller('loginCtrl', function($scope,$ionicPlatform, $state, $q, User, network) {
    $ionicPlatform.ready(function() {
        if(window.cordova){
          cordova.getAppVersion.getVersionNumber().then(function (version) {
            $scope.version = version;
          })
        }
      })
    $scope.user = { //与输入框ng-model绑定的数据必须写在一个object中才能正常获取和修改
        username: User.username,
        psw: User.psw
    };
    $scope.error = false; //错误信息不显示
    $scope.remb = false; //记住帐号
    // 自动登录
    if (User.username !== '') {
        var promise = User.login($scope.user);
        $q.when(promise)
            .then(function(data) {
                if (data.data.RESULT === 'PASS') {
                    //进入看板页面
                    $state.go('main');
                } else if (data.data.RESULT === 'FAIL') {
                    $scope.error = true;
                    $scope.errorMs = data.data.MESSAGE; //
                }

            }, function(error) {
                // console.log(error);
                $scope.error = true;
                $scope.errorMs = network.ip + '服务器连接错误！';
            });
    }
    // 登录
    $scope.login = function(user, rb) {
        if ($scope.user.username !== '' && $scope.user.psw !== '') {
            if ($scope.error) {
                $scope.error = false;
            }
            //提交服务器验证user
            var promise = User.login($scope.user);
            $q.when(promise)
                .then(function(data) {
                    if (data.data.RESULT === 'PASS') {
                        User.loginID = data.data.LOGIN_ID;
                        User.username = $scope.user.username;
                        User.psw = $scope.user.psw;
                        if (rb) {
                            User.saveUser();
                        }
                        $state.go('main');
                    } else if (data.data.RESULT === 'FAIL') {
                        $scope.error = true;
                        $scope.errorMs = data.data.MESSAGE; //
                    }

                }, function(error) {
                    // console.log(error);
                    $scope.error = true;
                    $scope.errorMs = network.ip + '服务器连接错误！';
                });
        } else {
            $scope.error = true;
            $scope.errorMs = '用户名、密码为必填项！';
        }
    };
})

.controller('mainCtrl', function($scope, $q, $ionicPlatform, $location, $ionicActionSheet, $state, $timeout, facList, User) {
    $scope.$on('$ionicView.enter', function(e) {
        var promise = facList.fetchMainData();
        $q.when(promise)
            .then(function(data) {
                if (data.data.RESULT === 'PASS') {
                    if (facList.factories) {
                        facList.factories.length = 0;
                    }
                    if (data.data.DATA.utidataset == null && data.data.DATA.outputsdataset != null) {
                        $scope.error = true;
                        $scope.errorMs = "稼动率获取数据null";
                        var outputsData = data.data.DATA.outputsdataset;
                        for (var i = 0; i < outputsData.length; i++) {
                            var facd = {};
                            facd.text = outputsData[i].seriesname;
                            facList.factories.push(facd);
                        }
                        $scope.dataSource2.categories = data.data.DATA.categories;
                        $scope.dataSource2.dataset = outputsData;
                    } else if (data.data.DATA.outputsdataset == null) {
                        $scope.error = true;
                        $scope.errorMs = "2H产出获取数据null";
                        var utiData = data.data.DATA.utidataset;
                        for (var i = 0; i < utiData.length; i++) {
                            var facd = {};
                            facd.text = utiData[i].seriesname;
                            facList.factories.push(facd);
                        }
                        $scope.dataSource1.categories = data.data.DATA.categories;
                        $scope.dataSource1.dataset = utiData;
                    } else {
                        $scope.error = false;
                        $scope.macTotal = data.data.DATA.macTotal;
                        var utiData = data.data.DATA.utidataset;
                        var outputsData = data.data.DATA.outputsdataset;
                        for (var i = 0; i < utiData.length; i++) {
                            var facd = {};
                            facd.text = utiData[i].seriesname;
                            facList.factories.push(facd);
                        }
                        $scope.dataSource1.categories = data.data.DATA.categories;
                        $scope.dataSource1.dataset = utiData;
                        $scope.dataSource2.categories = data.data.DATA.categories;
                        $scope.dataSource2.dataset = outputsData;
                    }
                } else if (data.data.RESULT === 'FAIL') {
                    $scope.error = true;
                    $scope.errorMs = "接口返回FAIL:"+data.data.MESSAGE; //
                }
            }, function(error) {
                $scope.error = true;
                if (error.status == 0) { //error.status/100 != 2
                    $scope.errorMs = '服务器连接超时！';
                }
            });
    })
    $scope.$on('$ionicView.leave', function(e) {
        //隐藏tooltip
        document.getElementById('fusioncharts-tooltip-element').style.display = 'none';
    })
    $scope.showSheet = function() {
        var body = document.body;
        if (ionic.Platform.isAndroid()) {
            angular.element(body).removeClass('platform-android').addClass('platform-ios');
        }
        var hideSheet = $ionicActionSheet.show({
            buttons: facList.factories,
            cancelText: '取消',
            cancel: function() {
                if (ionic.Platform.isAndroid()) {
                    angular.element(body).removeClass('platform-ios').addClass('platform-android');
                }
            },
            buttonClicked: function(index) {
                $state.go('factory', { fac: facList.factories[index].text });
            }
        });

        $timeout(function() {
            hideSheet();
        }, 2000);
    }
    $scope.goMachineStat = function() {
        $state.go('machineStatList');
    }
    $ionicPlatform.registerBackButtonAction(function(e) {
            if ($location.path() == '/main') {
                User.resetUser();
                $state.go('login');
            }
        }, 151)
        // $scope.events = {
        //     "renderComplete": function(eventObj, dataObj) {
        //         var svgs = document.getElementsByTagName('svg');
        //         angular.element(svgs).css('backgroundColor', 'transparent');
        //     }
        // }
    $scope.dataSource1 = {
        chart: {
            "caption": "稼动率汇总报表",
            "plotFillAlpha": "80",
            "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
            "numberSuffix": "%",
            // "numberPrefix": "%",
            "baseFont": "Helvetica Neue,Arial",
            "captionFontSize": "14",
            "subcaptionFontSize": "14",
            "subcaptionFontBold": "0",
            "showBorder": "0",
            "bgColor": "#ffffff",
            "showShadow": "0",
            "canvasBgColor": "transparent",
            "canvasBorderAlpha": "0",
            "divlineAlpha": "100",
            "divlineThickness": "1",
            "divLineIsDashed": "1",
            "divLineDashLen": "1",
            "divLineGapLen": "1",
            "usePlotGradientColor": "0",
            "showplotborder": "0",
            // "placeValuesInside": "1",
            "showHoverEffect": "1",
            // "rotateValues": "1",
            "showValues": "1",
            "showXAxisLine": "1",
            "xAxisLineThickness": "1",
            "showAlternateHGridColor": "0",
            "legendBgAlpha": "0",
            "legendBorderAlpha": "0",
            "legendShadow": "0",
            "legendItemFontSize": "10"
        },
        categories: [],
        dataset: []
    }
    $scope.dataSource2 = {
        chart: {
            "caption": "2小时产出汇总报表",
            "plotFillAlpha": "80",
            "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
            "baseFont": "Helvetica Neue,Arial",
            "captionFontSize": "14",
            "subcaptionFontSize": "14",
            "subcaptionFontBold": "0",
            "showBorder": "0",
            "bgColor": "#ffffff",
            "showShadow": "0",
            "canvasBgColor": "transparent",
            "canvasBorderAlpha": "0",
            "divlineAlpha": "100",
            "divlineThickness": "1",
            "divLineIsDashed": "1",
            "divLineDashLen": "1",
            "divLineGapLen": "1",
            "usePlotGradientColor": "0",
            "showplotborder": "0",
            "showHoverEffect": "1",
            "showValues": "1",
            "showXAxisLine": "1",
            "xAxisLineThickness": "1",
            "showAlternateHGridColor": "0",
            "legendBgAlpha": "0",
            "legendBorderAlpha": "0",
            "legendShadow": "0",
            "legendItemFontSize": "10"
        },
        categories: [],
        dataset: []
    }
})

.controller('factoryCtrl', function($scope, $state, $stateParams, facList) {
    $scope.factoryName = $stateParams.fac;
    $scope.goHome = function() {
        $state.go('main');
    }
    $scope.goGraph = function(state) {
        $state.go(state, { fac: $stateParams.fac });
    }
})

.controller('machineStatListCtrl', function($scope, $q, $state, $stateParams, facList) {
    $scope.$on('$ionicView.enter', function(e) {
        var promise = facList.fetchMachineStatList();
        $q.when(promise)
            .then(function(data) {
                if (data.data.RESULT === 'PASS' && data.data.DATA.length > 0) {
                    $scope.error = false;
                    $scope.dataList = data.data.DATA;
                    $scope.dataSource.dataset = data.data.TOTAL;
                } else if (data.data.RESULT === 'FAIL') {
                    $scope.error = true;
                    $scope.errorMs = data.data.MESSAGE; //
                }
            }, function(error) {
                $scope.error = true;
                if (error.status == 0) { //error.status/100 != 2
                    $scope.errorMs = '服务器连接超时！';
                }
            });
    })
    $scope.$on('$ionicView.leave', function(e) {
        //隐藏tooltip
        document.getElementById('fusioncharts-tooltip-element').style.display = 'none';
    })
    $scope.goHome = function() {
        $state.go('main');
    }
    $scope.goFac = function() {
        $state.go('machineStat', { fac: $stateParams.fac });
    }
    $scope.chart = {
        // "clickURL": "#/machineStat/1",
        "paletteColors": "#387ef5,#33cd5f,#ffc900,#ef473a",
        "bgColor": "#ffffff",
        "showBorder": "0",
        "use3DLighting": "0",
        "showShadow": "0",
        "enableSmartLabels": "1",
        "labelDistance": "-20",
        "smartLabelClearance": "0",
        "startingAngle": "250",
        "showLabels": "1",
        "showValues": "1",
        // "showPercentValues": "0",
        // "showPercentInTooltip": "1",
        "showLegend": "0",
        "showTooltip": "1",
        "decimals": "0",
        "showZeroPies": "1",
        "pieRadius": "80", //饼图外环半径
        "animation": "0",
        "slicingDistance": "0",
        "enableMultiSlicing": "0",
        "captionFontSize": "14",
        "plottooltext": "$label, $dataValue,  $percentValue"
    }
    $scope.attrs = function(title) {
        return JSON.parse('{"caption":"' + title + '","clickURL": "#/machineStat/' + title + '",' + JSON.stringify($scope.chart).substring(1))
    }
    $scope.dataList = []
    $scope.dataSource = {
        chart: {
            "plotFillAlpha": "80",
            "paletteColors": "#387ef5,#33cd5f,#ffc900,#ef473a",
            "baseFont": "Helvetica Neue,Arial",
            "captionFontSize": "14",
            "subcaptionFontSize": "14",
            "subcaptionFontBold": "0",
            "showBorder": "0",
            "bgColor": "#ffffff",
            "showShadow": "0",
            "canvasBgColor": "#ffffff",
            "canvasBorderAlpha": "0",
            "divlineAlpha": "0",
            "showAlternateVGridColor": "0",
            "usePlotGradientColor": "0",
            "showplotborder": "0",
            "showHoverEffect": "1",
            "showValues": "1",
            "showSum": "1",
            "showTooltip": "1",
            "showLimits": "0",
            "showDivLineValues": "0",
            "showXAxisLine": "0",
            "showAlternateHGridColor": "0",
            "legendBgAlpha": "0",
            "legendBorderAlpha": "0",
            "legendShadow": "0",
            "legendItemFontSize": "10"
        },
        "categories": [{
            "category": [{
                "label": "汇总"
            }]
        }],
        "dataset": []
    }
    $scope.events = {
            "renderComplete": function(eventObj, dataObj) {
                var svgs = document.getElementsByTagName('svg');
                // console.log('aaa');
                // angular.element(svgs).css('width', 'transparent');
            }
        }
})

.controller('utilrCtrl', function($scope, $state, $q, $stateParams, facList) {
    $scope.factoryName = $stateParams.fac;
    var ddate = new Date();
    ddate.setDate(ddate.getDate() - 1);
    $scope.data = { 'date': ddate };
    $scope.processData = {};
    $scope.goHome = function() {
        $state.go('main');
    }
    $scope.goFac = function() {
        $state.go('factory', { fac: $stateParams.fac });
    }
    $scope.$on('$ionicView.enter', function(e) {
        $scope.fetchUtiData();
    })
    $scope.$on('$ionicView.leave', function(e) {
        //隐藏tooltip
        document.getElementById('fusioncharts-tooltip-element').style.display = 'none';
    })
    $scope.fetchUtiData = function() {
        var promise = facList.fetchUtiData($scope.data.date.toJSON().substring(0, 10), $scope.factoryName);
        $q.when(promise)
            .then(function(data) {
                if (data.data.RESULT === 'PASS' && data.data.DATA.projectdata) {
                    $scope.error = false;
                    $scope.processData = data.data.DATA;
                    $scope.dataSource1.data = data.data.DATA.projectdata;
                    var protype = data.data.DATA.projectdata[0].label;
                    $scope.dataSource2.chart.subCaption = protype;
                    $scope.dataSource2.data = data.data.DATA.processType[protype];
                } else if (data.data.RESULT === 'FAIL') {
                    $scope.error = true;
                    $scope.dataSource1.data = [];
                    $scope.dataSource2.chart.subCaption = '项目';
                    $scope.dataSource2.data = [];
                    $scope.errorMs = data.data.MESSAGE; //
                } else if (!data.data.DATA.projectdata) {
                    $scope.error = true;
                    $scope.dataSource1.data = [];
                    $scope.dataSource2.chart.subCaption = '项目';
                    $scope.dataSource2.data = [];
                    $scope.errorMs = "接口返回数据缺失！"
                }
            }, function(error) {
                $scope.error = true;
                if (error.status == 0) { //error.status/100 != 2
                    $scope.errorMs = '服务器连接超时！';
                }
            });
    }
    $scope.events1 = {
        dataplotclick: function(ev, props) {
            if ($scope.processData.projectdata.length > 1) {
                $scope.$apply(function() {
                    $scope.dataSource2.chart.subCaption = props.categoryLabel + "项目";
                    var colors = $scope.dataSource1.chart.paletteColors.split(',');
                    $scope.dataSource2.chart.paletteColors = colors[props.index];
                    $scope.dataSource2.data = $scope.processData.processType[props.categoryLabel];
                });
            }
        }
    }
    $scope.dataSource1 = {
        chart: {
            "caption": "当日稼动率项目报表",
            "plotFillAlpha": "80",
            "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#444,#387ef5,#11c1f3,#33cd5f,#ffc900,#ef473a,#886aea",
            // "baseFontColor": "#fff",
            "numberSuffix": "%",
            "baseFont": "Helvetica Neue,Arial",
            "captionFontSize": "14",
            "subcaptionFontSize": "14",
            "subcaptionFontBold": "0",
            "showBorder": "0",
            "bgColor": "#ffffff",
            "showShadow": "0",
            "canvasBgColor": "#ffffff",
            "canvasBorderAlpha": "0",
            "divlineAlpha": "100",
            "divlineThickness": "1",
            "divLineIsDashed": "1",
            "divLineDashLen": "1",
            "divLineGapLen": "1",
            "usePlotGradientColor": "0",
            "showplotborder": "0",
            "showHoverEffect": "1",
            "showValues": "1",
            "showXAxisLine": "1",
            "xAxisLineThickness": "1",
            "showAlternateHGridColor": "0",
            "legendBgAlpha": "0",
            "legendBorderAlpha": "0",
            "legendShadow": "0",
            "legendItemFontSize": "10"
        },
        "data": []
    }
    $scope.dataSource2 = {
        chart: {
            "caption": "当日稼动率夹次报表",
            "subCaption": "项目",
            "plotFillAlpha": "80",
            "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
            "numberSuffix": "%",
            "baseFont": "Helvetica Neue,Arial",
            "captionFontSize": "14",
            "subcaptionFontSize": "14",
            "subcaptionFontBold": "0",
            "showBorder": "0",
            "bgColor": "#ffffff",
            "showShadow": "0",
            "canvasBgColor": "#ffffff",
            "canvasBorderAlpha": "0",
            "divlineAlpha": "100",
            "divlineThickness": "1",
            "divLineIsDashed": "1",
            "divLineDashLen": "1",
            "divLineGapLen": "1",
            "usePlotGradientColor": "0",
            "showplotborder": "0",
            "showHoverEffect": "1",
            "showValues": "1",
            "showXAxisLine": "1",
            "xAxisLineThickness": "1",
            "showAlternateHGridColor": "0",
            "legendBgAlpha": "0",
            "legendBorderAlpha": "0",
            "legendShadow": "0",
            "legendItemFontSize": "10"
        },
        "data": []
    }
})

.controller('2hOutputCtrl', function($scope, $state, $q, $stateParams, facList) {
    $scope.factoryName = $stateParams.fac;
    var ddate = new Date();
    ddate.setDate(ddate.getDate() - 1);
    $scope.data = {
        'date': ddate,
        'select': ''
    }
    $scope.selectList = []; //夹次数据；
    $scope.typeClear = true; //是否需要给夹次数组赋值
    $scope.processData = {}; //接口数据缓存
    $scope.goHome = function() {
        $state.go('main');
    }
    $scope.goFac = function() {
        $state.go('factory', { fac: $stateParams.fac });
    }
    $scope.$on('$ionicView.enter', function(e) {
        $scope.fetchOutputsData();
    })
    $scope.$on('$ionicView.leave', function(e) {
        //隐藏tooltip
        document.getElementById('fusioncharts-tooltip-element').style.display = 'none';
    })
    $scope.dateChanged = function() {
        $scope.typeClear = true;
        $scope.fetchOutputsData();
    }
    $scope.fetchOutputsData = function() {
        var type = '';
        if ($scope.data.select !== '所有夹次') {
            type = $scope.data.select;
        }
        var promise = facList.fetchOutputsData($scope.data.date.toJSON().substring(0, 10), $scope.factoryName, type);
        $q.when(promise)
            .then(function(data) {
                if (data.data.RESULT === 'PASS' && data.data.DATA.categories) {
                    $scope.error = false;
                    $scope.processData = data.data.DATA;
                    $scope.dataSource1.categories = data.data.DATA.categories;
                    $scope.dataSource1.dataset = data.data.DATA.dataset;
                    var protype = data.data.DATA.categories[0].category[0].label;
                    $scope.dataSource2.chart.subCaption = protype + "项目";
                    $scope.dataSource2.data = data.data.DATA.outputs[protype];
                    if ($scope.typeClear) { //无夹次数据，则赋值夹次
                        // $scope.selectList.length=0;
                        if (data.data.DATA.type.length > 1) {
                            $scope.selectList = ['所有夹次'].concat(data.data.DATA.type);
                            $scope.data.select = '所有夹次';
                        } else if (data.data.DATA.type.length == 1) {
                            $scope.selectList = $scope.selectList.concat(data.data.DATA.type);
                            $scope.data.select = $scope.selectList[0];
                        }
                        $scope.typeClear = false;
                    }
                } else if (data.data.RESULT === 'FAIL') {
                    $scope.dataSource1.categories = [];
                    $scope.dataSource1.dataset = [];
                    $scope.dataSource2.chart.subCaption = "项目";
                    $scope.dataSource2.data = [];
                    $scope.error = true;
                    $scope.errorMs = data.data.MESSAGE;
                } else if (!data.data.DATA.categories) {
                    $scope.dataSource1.categories = [];
                    $scope.dataSource1.dataset = [];
                    $scope.dataSource2.chart.subCaption = "项目";
                    $scope.dataSource2.data = [];
                    $scope.error = true;
                    $scope.errorMs = "接口返回数据缺失！";
                }
            }, function(error) {
                $scope.error = true;
                if (error.status == 0) { //error.status/100 != 2
                    $scope.errorMs = '服务器连接超时！';
                }
            });
    }
    $scope.events1 = {
        dataplotclick: function(ev, props) {
            if ($scope.processData.dataset.length > 1) {
                $scope.$apply(function() {
                    $scope.dataSource2.chart.subCaption = props.categoryLabel + "项目";
                    $scope.dataSource2.data = $scope.processData.outputs[props.categoryLabel];
                });
            }
        }
    }
    $scope.dataSource1 = {
        chart: {
            "caption": "当日2H产出项目报表",
            "plotFillAlpha": "80",
            "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#444,#387ef5,#11c1f3,#33cd5f,#ffc900,#ef473a,#886aea",
            // "baseFontColor": "#fff",
            // "numberSuffix": "%",
            "baseFont": "Helvetica Neue,Arial",
            "captionFontSize": "14",
            "subcaptionFontSize": "14",
            "subcaptionFontBold": "0",
            "showBorder": "0",
            "bgColor": "#ffffff",
            "showShadow": "0",
            "canvasBgColor": "#ffffff",
            "canvasBorderAlpha": "0",
            "divlineAlpha": "100",
            "divlineThickness": "1",
            "divLineIsDashed": "1",
            "divLineDashLen": "1",
            "divLineGapLen": "1",
            "usePlotGradientColor": "0",
            "showplotborder": "0",
            "showHoverEffect": "1",
            "showValues": "0",
            "showSum": "1",
            "showXAxisLine": "1",
            "xAxisLineThickness": "1",
            "showAlternateHGridColor": "0",
            "legendBgAlpha": "0",
            "legendBorderAlpha": "0",
            "legendShadow": "0",
            "legendItemFontSize": "10"
        },
        "categories": [],
        "dataset": []
    }
    $scope.dataSource2 = {
        chart: {
            "caption": "当日2H产出报表",
            "subCaption": "项目",
            "plotFillAlpha": "80",
            "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
            "baseFont": "Helvetica Neue,Arial",
            "captionFontSize": "14",
            "subcaptionFontSize": "14",
            "subcaptionFontBold": "0",
            "showBorder": "0",
            "bgColor": "#ffffff",
            "showShadow": "0",
            "canvasBgColor": "#ffffff",
            "canvasBorderAlpha": "0",
            "divlineAlpha": "100",
            "divlineThickness": "1",
            "divLineIsDashed": "1",
            "divLineDashLen": "1",
            "divLineGapLen": "1",
            "usePlotGradientColor": "0",
            "showplotborder": "0",
            "showHoverEffect": "1",
            "showValues": "1",
            "showXAxisLine": "1",
            "xAxisLineThickness": "1",
            "showAlternateHGridColor": "0",
            "legendBgAlpha": "0",
            "legendBorderAlpha": "0",
            "legendShadow": "0",
            "legendItemFontSize": "10"
        },
        "data": []
    }
})

.controller('machineStatCtrl', function($scope, $q, $state, $stateParams, facList) {
    $scope.factoryName = $stateParams.fac;
    $scope.$on('$ionicView.enter', function(e) {
        $scope.plantIndex = 0; //厂房索引
        var promise = facList.fetchMachineStat($scope.factoryName);
        $q.when(promise)
            .then(function(data) {
                if (data.data.RESULT === 'PASS' && data.data.DATA.length > 0) {
                    $scope.error = false;
                    $scope.dataList = data.data.DATA;
                    if (data.data.DATA.length == 1) {
                        document.getElementById('facTotalChart').style.display = "none";
                        $scope.ctrChart = true;
                    } else {
                        $scope.dataSource.dataset = data.data.TOTAL;
                        // var svgt = document.querySelector("#facTotalChart svg");
                        // console.log(svgt.getAttribute("width"));
                        // svgt.setAttribute("width","355");
                    }
                    facList.drawCanvas($scope.dataList[$scope.plantIndex].macList,$scope.dataList[$scope.plantIndex].xMax,$scope.dataList[$scope.plantIndex].yMax);
                } else if (data.data.RESULT === 'FAIL') {
                    $scope.error = true;
                    $scope.errorMs = data.data.MESSAGE; //
                }
            }, function(error) {
                $scope.error = true;
                if (error.status == 0) { //error.status/100 != 2
                    $scope.errorMs = '服务器连接超时！';
                }
            });
    })
    $scope.$on('$ionicView.leave', function(e) {
        //隐藏tooltip
        document.getElementById('fusioncharts-tooltip-element').style.display = 'none';
    })
    $scope.goHome = function() {
        $state.go('main');
    }
    $scope.goFac = function() {
        $state.go('factory', { fac: $stateParams.fac });
    }
    $scope.goMac = function() {
        $state.go('machineStatList');
    }
    $scope.chart = {
        "paletteColors": "#387ef5,#33cd5f,#ffc900,#ef473a",
        "bgColor": "#ffffff",
        "showBorder": "0",
        "use3DLighting": "0",
        "showShadow": "0",
        "enableSmartLabels": "1",
        "labelDistance": "-20",
        "smartLabelClearance": "0",
        "startingAngle": "250",
        "showLabels": "1",
        "showPercentValues": "0",
        "showPercentInTooltip": "1",
        "showLegend": "0",
        // "legendBgAlpha": "0",
        // "legendBorderAlpha": "0",
        // "legendShadow": "0",
        // "legendItemFontSize": "10",
        // "legendItemFontColor": "#fff",
        // "defaultCenterLabel": "",
        // "centerLabel": "$label: $value",
        // "centerLabelBold": "1",
        // "centerLabelColor": "#ffffff",
        // "useDataPlotColorForLabels": "1",
        "showTooltip": "1",
        "decimals": "0",
        "showZeroPies": "1",
        "pieRadius": "80", //饼图外环半径
        "animation": "0",
        "slicingDistance": "0",
        "enableMultiSlicing": "0",
        // "doughnutRadius":"10",//饼图内环半径
        "captionFontSize": "14",
        "plottooltext": "$label, $dataValue,  $percentValue"
    }
    $scope.attrs = function(title) {
        return JSON.parse('{"caption":"' + title + '",' + JSON.stringify($scope.chart).substring(1))
    }
    $scope.events = {
        chartClick: function(ev, props) {
            $scope.$apply(function() {
                $scope.plantIndex = Number(props.container.id);
                facList.clearCanvas();
                facList.drawCanvas($scope.dataList[$scope.plantIndex].macList,$scope.dataList[$scope.plantIndex].xMax,$scope.dataList[$scope.plantIndex].yMax);
            });
        }
    }
    $scope.dataList = [];
    $scope.dataSource = {
        chart: {
            "plotFillAlpha": "80",
            "paletteColors": "#387ef5,#33cd5f,#ffc900,#ef473a",
            "baseFont": "Helvetica Neue,Arial",
            "captionFontSize": "14",
            "subcaptionFontSize": "14",
            "subcaptionFontBold": "0",
            "showBorder": "0",
            "bgColor": "#ffffff",
            "showShadow": "0",
            "canvasBgColor": "#ffffff",
            "canvasBorderAlpha": "0",
            "divlineAlpha": "0",
            "showAlternateVGridColor": "0",
            "usePlotGradientColor": "0",
            "showplotborder": "0",
            "showHoverEffect": "1",
            "showValues": "1",
            "showSum": "1",
            "showTooltip": "1",
            "showLimits": "0",
            "showDivLineValues": "0",
            "showXAxisLine": "0",
            "showAlternateHGridColor": "0",
            "legendBgAlpha": "0",
            "legendBorderAlpha": "0",
            "legendShadow": "0",
            "legendItemFontSize": "10"
        },
        "categories": [{
            "category": [{
                "label": "汇总"
            }]
        }],
        "dataset": []
    }
})
