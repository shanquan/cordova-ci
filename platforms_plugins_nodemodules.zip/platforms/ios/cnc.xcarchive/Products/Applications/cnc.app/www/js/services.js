angular.module('starter.services', [])

 .factory('network', function () {
    //var ip = '10.6.78.127/blfms/api'; 内网服务器ip
    var ip = '121.15.254.143:5120/blfms/api';
    return {
      ip: ip
    }
  })

  .factory('restaurantInfo', function($http, network) {
    
    return {
      /**
       * 得到所有的餐厅列表
       * @returns {HttpPromise}
       * @memberOf services.restaurantInfo
       */
      GetAllRestaurantInfo: function () {
        var promise = $http.get('http://' + network.ip + '/allResInfo');
        return promise;
      },
      /**
       * 获取该餐厅所有的菜品标签
       * @param {string} restaurantId 选择的餐厅ID
       * @returns {HttpPromise}
       * @memberOf services.restaurantInfo
       */
      GetSomeResAllTags: function (restaurantId) {
        var promise = $http.get('http://' + network.ip + '/getSomeResAllTags?restaurantId=' + restaurantId);
        return promise;
      },
      /**
       * 根据某个餐厅ID及菜品标签获取该餐厅菜品相关信息
       * @param {string} restaurantId 选择的餐厅ID
       * @param {string} tag 选择的餐厅菜品标签
       * @returns {HttpPromise}
       * @memberOf services.restaurantInfo
       */
      GetSomeResData: function (restaurantId,tag) {
        if(tag){
          var promise = $http.get('http://' + network.ip + '/getSomeResData?restaurantId=' + restaurantId + '&tags=' + tag);
        }else{
          var promise = $http.get('http://' + network.ip + '/getSomeResData?restaurantId=' + restaurantId);
        }
        return promise;
      },
      /**
       * 点餐完毕后签名提交
       * @param {object} body 提交的信息：餐厅ID，菜单，客户姓名及备注
       * @returns {HttpPromise}
       * @memberOf services.submit
       */
      Submit: function (body) {
        var promise = $http({
            method: 'POST',
            url: 'http://' + network.ip + '/submit',
            data: body
        });
        return promise;
      },
      /**
       * 历史订单查询
       * @param {string} startDate 开始日期
       * @param {string} endDate 结束日期
       * @returns {HttpPromise}
       * @memberOf services.restaurantInfo
       */
      GethistoricalOrderQuery: function (startDate,endDate) {
        var promise = $http.get('http://' + network.ip + '/historicalOrderQuery?start=' + startDate + '&end=' + endDate);
        return promise;
      }
    };
  });
