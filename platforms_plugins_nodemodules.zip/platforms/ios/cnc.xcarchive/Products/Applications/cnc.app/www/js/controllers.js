angular.module('starter.controllers', ['angucomplete-alt'])

.controller('languageCtrl', function($scope,$state) {
  $scope.Chinese=function(){
    localStorage.setItem('language','Chinese');
    $state.go('tab.restaurants');
  }
  $scope.English=function(){
    localStorage.setItem('language','English');
    $state.go('tab.restaurants');
  }
})
.controller('tabsCtrl', function($scope,$state) {
  $scope.$on('$ionicView.enter', function (e) {    
    if(localStorage.getItem('language')=='Chinese'){
      $scope.resQuery='餐厅查询';
      $scope.hisOrder='历史订单';
    }else{
      $scope.resQuery="Restaurant Query";
      $scope.hisOrder="History Order";
    }
  })
})
.controller('restaurantsCtrl', function($scope,$q,$state,restaurantInfo) {
  $scope.$on('$ionicView.enter', function (e) {
    GetAllRestaurantsInfo();
  })
  $scope.goLanguage = function() {
    $state.go('language');
  }
  GetAllRestaurantsInfo = function () {
    var promise = restaurantInfo.GetAllRestaurantInfo(); 
    $q.when(promise)
      .then(function (data) {
        if (data.data.results === 'PASS') {
          $scope.allResInfo = data.data.data;
          if(localStorage.getItem('language')=='Chinese'){
            $scope.titleName="餐厅查询";
            for(var i=0;i<$scope.allResInfo.length;i++){
              $scope.allResInfo[i]['index'] = i+1;
              $scope.allResInfo[i]['name'] = $scope.allResInfo[i].ChineseResName;
            }
          } else {
            $scope.titleName="Restaurant Query";
            for(var i=0;i<$scope.allResInfo.length;i++){
              $scope.allResInfo[i]['index'] = i+1;
              $scope.allResInfo[i]['name'] = $scope.allResInfo[i].EnglishResName;
            }
          }
        } else {
          $scope.error = true;
          $scope.errorMs = data.data.message;
        }
      }, function(error){
        $scope.error = true;
        $scope.errorMs = '服务器连接错误！';
    });
  };
  $scope.goRestaurant = function(item){
    localStorage.setItem('resId',item.restaurantId);
    localStorage.setItem('resName',item.name);
    $state.go('restaurant');
  }
})
.controller('hisOrdersCtrl', function($scope,$q,$state,restaurantInfo) {
  $scope.$on('$ionicView.enter', function (e) {
    GethistoricalOrderQuery();
    $scope.historicalOrderData = [];
  })
  $scope.goLanguage = function() {
    $state.go('language');
  }
  GethistoricalOrderQuery = function () {
    var myDate = new Date();
    var myMonth = (myDate.getMonth()+1)>9?(myDate.getMonth()+1):('0'+(myDate.getMonth()+1));
    var myDay = myDate.getDate()>9?myDate.getDate():('0'+myDate.getDate());
    var startDate = myDate.getFullYear()+'-'+myMonth+'-'+myDay;
    var endDate = myDate.getFullYear()+'-'+myMonth+'-'+myDay;
    var promise = restaurantInfo.GethistoricalOrderQuery(startDate,endDate); 
    $q.when(promise)
      .then(function (data) {
        if (data.data.results === 'PASS') {
          if(data.data.data.length>0){            
            $scope.historicalOrderQuery = data.data.data;
            $scope.historicalOrderQuery.sort(function(a,b){
              return Date.parse((a.orderTime).replace(/-/g, '/')) - Date.parse((b.orderTime).replace(/-/g, '/'));//时间正序
            })
            //console.log($scope.historicalOrderQuery)
            if(localStorage.getItem('language')=='Chinese'){
              $scope.Chinese=true;
              $scope.titleName="历史订单";
              for(var i=$scope.historicalOrderQuery.length-1;i>-1;i--){
                $scope.historicalOrderQuery[i].dishList
                $scope.historicalOrderData.push({
                  'customer':$scope.historicalOrderQuery[i].customer,
                  'resName':$scope.historicalOrderQuery[i].ChineseResName,
                  'remarks':$scope.historicalOrderQuery[i].remarks,
                  'orderTime':$scope.historicalOrderQuery[i].orderTime.substring(11),
                  'dishList':$scope.historicalOrderQuery[i].dishList.map(function(item){
                    return {
                      resName:item.dishChineseName,
                      dishNum:item.dishNum
                    }
                  })
                });
              }
            } else {
              $scope.titleName="History Order";
              $scope.Chinese=false;
              for(var i=$scope.historicalOrderQuery.length-1;i>-1;i--){
                $scope.historicalOrderData.push({
                  'customer':$scope.historicalOrderQuery[i].customer,
                  'resName':$scope.historicalOrderQuery[i].EnglishResName,
                  'remarks':$scope.historicalOrderQuery[i].remarks,
                  'orderTime':$scope.historicalOrderQuery[i].orderTime.substring(11),
                  'dishList':$scope.historicalOrderQuery[i].dishList.map(function(item){
                    return {
                      resName:item.dishEnglishName,
                      dishNum:item.dishNum
                    }
                  })
                });
              }
            }
          }else{
            $scope.error = true;
            if(localStorage.getItem('language')=='Chinese'){
              $scope.errorMs = '此时无今日就餐数据';
            }else{
              $scope.errorMs = 'Today has no historical order';
            }            
          }
        } else {
          $scope.error = true;
          $scope.errorMs = data.data.message;
        }
      }, function(error) {
        $scope.error = true;
        $scope.errorMs = '服务器连接错误！';
    });
  };
})
.controller('restaurantCtrl', function($scope,$q,$ionicPopup,$state,$ionicHistory,restaurantInfo) {
  var resId ='';
  var tag = '';
  var totalCount = 0;
  var dishList = [];
  $scope.dishList = dishList;
  $scope.$on('$ionicView.enter', function (e) {
    dishList = [];
    submitRemark = '';
    $scope.restaurantName = localStorage.getItem('resName');
    document.getElementById('checkMenu').disabled="true";
    resId = localStorage.getItem('resId');
    GetSomeResAllTags(resId);
    GetSomeResData(resId);
  });
  $scope.goBack = function() {
    $ionicHistory.goBack(-1)
  };
  GetSomeResAllTags = function(resId){
    $scope.allResTagsArray = [];
    var promise = restaurantInfo.GetSomeResAllTags(resId); 
    $q.when(promise)
      .then(function (data) {
        if (data.data.results === 'PASS') {
          $scope.allResTags = data.data.data;
          if(localStorage.getItem('language')=='Chinese'){
            $scope.dItem = '默认';
            $scope.checkMenuName = '检查菜单';
            $scope.checkDishList = '已选菜品';
            $scope.clearButton = '清空';
            $scope.cancelButton = '取消';
            $scope.nextButton = '提交';
            $scope.submitButton = '提交';
            $scope.customerName = '客户姓名';
            $scope.clientSideList = [
              {index:0,value:'不要辣',color:'#444'},
              {index:1,value:'微辣',color:'#444'},
              {index:2,value:'不要葱',color:'#444'},
              {index:3,value:'不要香菜',color:'#444'},
              {index:4,value:'少油',color:'#444'},
              {index:5,value:'少盐',color:'#444'}
            ];
            $scope.allResTagsName = $scope.allResTags.Chinesetags;
          } else {
            $scope.dItem = 'default';
            $scope.checkMenuName = 'checkMenu';
            $scope.checkDishList = 'Check Dishlist';
            $scope.clearButton = 'clear';
            $scope.cancelButton = 'cancel';
            $scope.nextButton = 'submit';
            $scope.submitButton = 'submit';
            $scope.customerName = 'customerName';
            $scope.clientSideList = [
              {index:0,value:'mild',color:'#444'},
              {index:1,value:'spicy',color:'#444'},
              {index:2,value:'no onion',color:'#444'},
              {index:3,value:'no coriander',color:'#444'},
              {index:4,value:'less oil',color:'#444'},
              {index:5,value:'less salt',color:'#444'}
            ];
            $scope.allResTagsName = $scope.allResTags.Englishtags;
          }
          for(var i=0;i<$scope.allResTagsName.length;i++){
            $scope.allResTagsArray.push({
              'index':i,
              'color':'#444',
              'resTagName':$scope.allResTagsName[i]
            });
          }
          for(var i=0;i<$scope.allResTagsArray.length;i++){
            if($scope.allResTagsArray[i].resTagName=="null"){
              swapArr($scope.allResTagsArray,0,i);
              $scope.allResTagsArray[i].index=i;
              $scope.allResTagsArray[0].index=0;
            }
          }
        } else {
          $scope.error = true;
          $scope.errorMs = data.data.message;
        }
      }, function(error) {
        $scope.error = true;
        $scope.errorMs = '服务器连接错误！';
    });
  }
  /*数组两个元素位置互换*/
  var swapArr = function(arr, index1, index2){
    arr[index1] = arr.splice(index2, 1, arr[index1])[0];
    return arr;
  }
  $scope.chooseTag = function(item){
    for(var i=0;i<$scope.allResTagsArray.length;i++){
      if(i==item.index){
        $scope.allResTagsArray[i].color='#11C1F3';
      }else{
        $scope.allResTagsArray[i].color='#444';
      }
    }
    localStorage.setItem('chooseTag',item);
    GetSomeResData(resId,item);
  }
  GetSomeResData = function(resId,item){
    var promise = restaurantInfo.GetSomeResData(resId,item?item.resTagName:''); 
    $q.when(promise)
      .then(function (data) {
        if (data.data.results === 'PASS') {
          $scope.allResDishData = data.data.data.dishList;
          if($scope.allResDishData.length>0){ 
            $scope.error = false; 
            if(localStorage.getItem('language')=='Chinese'){
              for(var i=0;i<$scope.allResDishData.length;i++){
                $scope.allResDishData[i]['name'] = $scope.allResDishData[i].dishChineseName;
                //$scope.allResDishData[i]['count'] = 0;
              }
            } else {
              for(var i=0;i<$scope.allResDishData.length;i++){
                $scope.allResDishData[i]['name'] = $scope.allResDishData[i].dishEnglishName;
                //$scope.allResDishData[i]['count'] = 0;
              }
            }            
            for(var i=0;i<$scope.allResDishData.length;i++){                       
              if(dishList.length>0){
                for(var j=0;j<dishList.length;j++){
                  if($scope.allResDishData[i].name==dishList[j].dishName){
                    $scope.allResDishData[i]['count'] = dishList[j].dishNum;
                    break;
                  }else{
                    $scope.allResDishData[i]['count'] = 0;
                  }
                }
              }else{
                $scope.allResDishData[i]['count'] = 0;
              }
            }
          }else{
            $scope.error = true;
            if(localStorage.getItem('language')=='Chinese'){
              $scope.errorMs = localStorage.getItem('resName')+'当前没有菜品提供';
            }else{
              $scope.errorMs = 'No dishes available at present';
            }
          }
        } else {
          $scope.error = true;
          $scope.errorMs = data.data.message;
        }
      }, function(error) {
        $scope.error = true;
        $scope.errorMs = '服务器连接错误！';
    });
  }
  $scope.addDish = function(item){
    totalCount++;
    enableCheckMenuButton();
    item.count++;
    if(totalCount==1){
      dishList.push({"dishId":item.dishId,"dishName":item.name,"dishNum":item.count});
    }else{
      for(var i=0;i<dishList.length;i++){
        if(item.dishId==dishList[i].dishId){
          dishList.splice(i, 1);
        }
      }
      dishList.push({"dishId":item.dishId,"dishName":item.name,"dishNum":item.count});
    }   
  }
  $scope.minusDish = function(item){    
    if(totalCount>0){
      item.count--;
      if(item.count>0){        
        for(var i=0;i<dishList.length;i++){
          if(item.dishId==dishList[i].dishId){
            dishList[i].dishNum=item.count;
          }
        }
      }else{
        item.count=0;
        for(var i=0;i<dishList.length;i++){
          if(item.dishId==dishList[i].dishId){
            dishList.splice(i, 1);
          }
        }
      }
    }else{
      item.count=0;
      totalCount=0;
    }
    checkTotalCount();   
  }
  enableCheckMenuButton = function(){
    document.getElementById("checkMenu").disabled="";
  }
  disableCheckMenuButton = function(){
    document.getElementById('checkMenu').disabled="true";
  }
  //客户名称去重
  function unique(arr){            
    for(var i=0; i<arr.length; i++){
        for(var j=i+1; j<arr.length; j++){
            if(arr[i].cusName==arr[j].cusName){         //第一个等同于第二个，splice方法删除第二个
                arr.splice(j,1);
                j--;
            }
        }
    }
    return arr;
  }
  var checkTotalCount = function(){
    totalCount=0;
    for(var i=0;i<dishList.length;i++){
      totalCount+=dishList[i].dishNum;
    }
    if(totalCount==0){
      disableCheckMenuButton();
    } 
  }
  $scope.checkMenu = function(){
    $scope.dishList=dishList;
    for(var i=0;i<$scope.dishList.length;i++){
      while($scope.dishList[i].dishNum==0){
        $scope.dishList.splice(i, 1);
      }
    }
    var myPopup = $ionicPopup.show({
      cssClass:'team-popup',
      template: "<div class='list popup-form'>" +
      "<div class = 'form-title'>{{checkDishList}}</div>" +
      "<div class='form-content' ng-repeat='item in dishList'>" +
       "<div class='input-name' style='width:80%!important;'>{{item.dishName}}:</div>" +
       "<div class='input-name' style='width:20%!important;'>{{item.dishNum}}</div>" +
      "</div>" +
      "<div class='form-button'>" +
       "<button class='button wyl-left-button' ng-click='cancel()' >{{cancelButton}}</button>" +
       "<button class='button wyl-right-button' ng-click='next()' >{{nextButton}}</button>" +
       "<button class='button wyl-middle-button' ng-click='clear()' >{{clearButton}}</button>" +
      "</div>" +
      "</div>",
      scope: $scope
    });
    $scope.cancel = function(){
      myPopup.close();
    }
    $scope.clear = function(){
      myPopup.close();
      for(var i=0;i<$scope.allResDishData.length;i++){
        $scope.allResDishData[i].count=0;
        document.getElementById('checkMenu').disabled="true";
      }
      for(var i=0;i<$scope.dishList.length;i++){
        $scope.dishList[i].dishNum=0;
      }
    }
    $scope.data={
      cusNameSubmit:''
    }    
    $scope.focusOut = function(){
      if(!$scope.selected){
        $scope.$broadcast('angucomplete-alt:clearInput', 'demoCusName');
        //获取全部客户姓名数据缓存
        setBaseData($scope.cusNameList);
      }
    }
    var getCusNameList = function () {
      $scope.cusNameList = [];
      var myDate = new Date();
      var myMonth = (myDate.getMonth()+1)>9?(myDate.getMonth()+1):('0'+(myDate.getMonth()+1));
      var myDay = myDate.getDate()>9?myDate.getDate():('0'+myDate.getDate());
      var startDate = '2020-01-09';
      var endDate = myDate.getFullYear()+'-'+myMonth+'-'+myDay;
      var promise = restaurantInfo.GethistoricalOrderQuery(startDate,endDate); 
      $q.when(promise)
        .then(function (data) {
          if (data.data.results === 'PASS') {
            $scope.historicalOrderQuery=data.data.data;
            $scope.historicalOrderQuery.sort(function(a,b){
              return Date.parse(a.orderTime) - Date.parse(b.orderTime);//时间正序
            })
            for(var i=0;i<$scope.historicalOrderQuery.length;i++){              
              $scope.cusNameList.push({
                'cusName':$scope.historicalOrderQuery[i].customer                
              });
            } 
            $scope.cusNameList = unique($scope.cusNameList).reverse();
            //姓名记忆只保存50个
            if($scope.cusNameList.length>50){
              $scope.cusNameList.splice(50,$scope.cusNameList.length-50);
            }
          } else {
            $scope.error = true;
            $scope.errorMs = data.data.message;
          }
        }, function(error) {
          $scope.error = true;
          $scope.errorMs = '服务器连接错误！';
      });
    };
    getCusNameList();
    $scope.next = function(){
      myPopup.close();
      var subPopup = $ionicPopup.show({
        cssClass:'team-popup',
        template: "<div class='list popup-form' style='height:230px;'>" +
        "<div class='form-content'>" +
        "<div class='input-name'>{{customerName}}&nbsp;&nbsp;:</div>" +
         // "<div class='input-name'><input type='string' placeholder='David' ng-model='data.cusName' style='border:none;'></div>" +
         "<div class='input-name'><angucomplete-alt id='demoCusName' pause='100' selected-object='getCusName' local-data='cusNameList' search-fields='cusName' title-field='cusName' minlength='1' input-class='form-control form-control-small' match-class='highlight'></angucomplete-alt></div>" +
        "</div>" +
        "<div class='form-remark' ng-repeat='item in clientSideList'>" +
          "<button class='button button-stable' ng-click='chooseRemark(item)' ng-style='{color:item.color}'>{{item.value}}</button>" +
        "</div>" + 
        "<div class='form-button'>" + 
         "<button class='button wyl-left-button' ng-click='cancel()' style='width: 50%;margin-top: 10px;'>{{cancelButton}}</button>" +
         "<button class='button wyl-right-button' ng-click='submit()' style='width: 50%;margin-top: 10px;'>{{submitButton}}</button>" +
        "</div>" + 
        "</div>",
        scope: $scope
       });
      $scope.cancel = function(){
        subPopup.close();
      }
      var submitRemark = '';
      $scope.chooseRemark = function(item){
        item.color='red';
        for(var i=0;i<$scope.clientSideList.length;i++){
          if(i==item.index){
            $scope.clientSideList[i].color='red';
          }else{
            $scope.clientSideList[i].color='#444';
          }
        }
        submitRemark = item.value;
        //localStorage.setItem('remark',item.value);
      }
      $scope.submit = function(){
        var dishListSubmit = [];
        for(var i=0;i<dishList.length;i++){
          dishListSubmit.push({'dishId':dishList[i].dishId,'dishNum':dishList[i].dishNum});
        }
        if(document.getElementById('demoCusName_value').value==''){
          alert('请先签名！')
        } 
        if(submitRemark==''){
          alert('请填写备注！')
        }
        var body = {
          "restaurantId": localStorage.getItem('resId'),
          "dishList": dishListSubmit,
          "customer": document.getElementById('demoCusName_value').value,
          "remarks": submitRemark
        }
        restaurantInfo.Submit(body).then(function (data) {
          if (data.data.results === 'PASS') {            
            if(localStorage.getItem('language')=='Chinese'){
              subPopup.close();
              alert('提交成功！'); 
              $state.go('language');             
            }else{
              subPopup.close();
              alert('submit!');
              $state.go('language');  
            }            
          } else {
            subPopup.close();
            alert(data.data.message);
          }
        }, function(error) {
          $scope.error = true;
          $scope.errorMs = '服务器连接错误！';
        });
      }
    }
  };
})
